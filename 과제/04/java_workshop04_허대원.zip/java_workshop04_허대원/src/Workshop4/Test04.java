package Workshop4;

public class Test04 {

	public static void main(String[] args) {
		Calc cal = new Calc();
		int num = Integer.parseInt(args[0]);
		if(num >= 5 && num <= 10) {
			System.out.println("결과 : " + cal.calculate(Integer.parseInt(args[0])));
		}else {
			System.out.println("5 ~ 10 까지 정수를 입력하세요.");
		}
		
	}

}
