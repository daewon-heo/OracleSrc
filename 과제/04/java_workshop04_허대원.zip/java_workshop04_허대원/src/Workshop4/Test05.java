package Workshop4;

public class Test05 {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		int sum = 0;
		String result = "";
		
		if(num >= 1 && num <= 5) {
			for (int i = num; i <= 10; i++) {
				if(i%3 != 0 && i%5 != 0) {
					result += i + "+";
					sum += i;
				}
			}
			result = result.substring(0, result.length() - 1);
			System.out.println(result);
			System.out.println("결과 : " + sum);
		}else {
			System.out.println("1 ~ 5까지 정수를 입력하세요.");
		}
	}
}
