package Workshop4;

public class Test02 {

	public static void main(String[] args) {
		boolean option = true; // option true : 중복 허용, false : 중복 불가
		
		int[] arr3 = new int[5];
		
		if(option) {	// 랜덤 허용할 지 체크
			// 랜덤 입력부
			for(int i = 0 ; i < arr3.length; i++) {
				arr3[i] = (int)(Math.random()*10) + 1;
			}
		}else {
			int cnt = 0;
			label:
			while(true){
				int random = (int)(Math.random()*10) + 1;
				for (int i = 0; i <= cnt; i++) {
					if(arr3[i] == random) {
						break;
					}
					
					if(i == cnt) {
						arr3[cnt++] = random;
						break;
					}
					
					if(cnt == 5) break label;
				}
			}
		}
		
		
		int sum = 0;

		// 출력부
		for (int i = 0; i < arr3.length; i++) {
			System.out.println(arr3[i]);
			sum += arr3[i];
		}
		
		double count = arr3.length;
		
		// 합&평균 출력
		System.out.println("sum = " + sum);
		System.out.printf("avg = %.1f" , sum/count);
	}

}
