package Workshop4;

public class Test06 {

	public static void main(String[] args) {
		if(args.length != 2) {
			System.out.println("다시 입력하세요.");
		}else {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			if(num1 >= 1 && num1 <= 5 && num2 >= 1 && num2 <= 5) {
				// 배열 초기화
				int[][] arr6 = new int[num1][num2];
				int sum = 0;
				double cnt = 0;
				
				// 입력부
				for (int i = 0; i < arr6.length; i++) {
					for (int j = 0; j < arr6[i].length; j++) {
						arr6[i][j] = (int)(Math.random()*5)+1;
					}
				}
				
				// 출력부
				for (int i = 0; i < arr6.length; i++) {
					for (int j = 0; j < arr6[i].length; j++) {
						System.out.print(arr6[i][j] + " ");
						sum += arr6[i][j];
						cnt++;
					}
					System.out.println();
				}

				System.out.println();

				// 합 & 평균 출력
				System.out.println("sum = " + sum);
				System.out.println("avg = " + sum/cnt);
				
			}else {
				System.out.println("숫자를 확인하세요.");
			}
		}
	}

}
