package Workshop4;

public class Calc {
	public int calculate(int data) {
		int result = 0;
		System.out.println("입력값 : " + data);
		
		System.out.print("짝수 : ");
		for(int i = 1 ; i <= data ; i++) {
			if(i%2 == 0) {
				System.out.print(i + " ");
				result += i;
			}
		}
		System.out.println();
		return result;
	}
}
