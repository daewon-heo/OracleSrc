package account;

public class Account {
	private String account;
	private int balance;
	private double interestRate;

	public Account() {
	}

	public Account(String account, int balance, double interestRate) {
		this.account = account;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	
	public String accountInfo() {
		return "계좌번호 : " + this.account + "\t잔액 : " + this.balance + "원\t이자율 : " + this.interestRate + "%";
	}
	
	// 현재 잔액을 기준으로 이자를 계산 한다
	public double calculateInterest() {
		return 0;
	}
	
	// 입금을 통해 잔액정보를 증가 시킨다
	public void deposit(int money) {
		this.balance += money;
	}
	
	// 출금을 통해 잔액정보를 감소 시킨다
	public void withdraw(int money) {
		this.balance -= money;
	}

	// 계좌정보를 리턴
	public String getAccount() {
		return account;
	}
	
	// 계좌정보를 셋팅
	public void setAccount(String account) {
		this.account = account;
	}

	// 잔액정보를 리턴
	public int getBalance() {
		return balance;
	}
	
	public double getInterestRate() {
		return interestRate;
	}
	
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
}
