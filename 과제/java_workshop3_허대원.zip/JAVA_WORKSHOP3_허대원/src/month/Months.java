package month;

public class Months {
	public int getDays(int months) {
		int[] endDays = {31,28,31,30,31,30,31,31,30,31,30,31}; 
		return endDays[months-1];
	}
}
