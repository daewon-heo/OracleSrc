package month;

public class MonthsTest {

	public static void main(String[] args) {
		if(args.length == 1) {
			int num = Integer.parseInt(args[0]);
			if(num >= 1 && num <= 12) {
				System.out.println("입력받은 월 : " + num + "월");
				
				Months months = new Months();
				System.out.println("마지막 일자 : " + months.getDays(num) + "일");
			}else {
				System.out.println("입력된 값이 잘못 되었습니다.");
			}
		}else {
			System.out.println("다시 입력해 주세요.");
		}
	}
}
